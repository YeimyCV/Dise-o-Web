window.addEventListener("load", function () {

    let btnReservar = document.getElementById("btnReservar")

    btnReservar.addEventListener('click', function () {
        window.open("pdf/trabajos ejemplo.pdf","_blank")
     })
  
})


const navItems = document.querySelectorAll('.nav-item');

navItems.forEach(item => {
  item.addEventListener('click', () => {
    navItems.forEach(i => i.classList.remove('selected'));
    item.classList.add('selected');
  });
});